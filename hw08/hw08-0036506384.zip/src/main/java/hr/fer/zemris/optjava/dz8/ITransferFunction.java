package hr.fer.zemris.optjava.dz8;

public interface ITransferFunction {

    double output(double input);
}
