package hr.fer.zemris.optjava.dz7;

public interface ANNTrainingAlgorithm {
    void train(FFANN network);
}
