package hr.fer.zemris.optjava.dz7;

public interface ITransferFunction {

    double output(double input);
}
