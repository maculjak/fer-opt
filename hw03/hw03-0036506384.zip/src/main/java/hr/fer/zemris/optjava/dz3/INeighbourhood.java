package hr.fer.zemris.optjava.dz3;

public interface INeighbourhood <T> {

    T randomNeighbour(T solution);
}
