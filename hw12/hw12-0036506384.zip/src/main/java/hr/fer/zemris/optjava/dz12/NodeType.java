package hr.fer.zemris.optjava.dz12;

public enum NodeType {
    Left, Move, Right, Prog2, Prog3, IfFoodAhead
}
