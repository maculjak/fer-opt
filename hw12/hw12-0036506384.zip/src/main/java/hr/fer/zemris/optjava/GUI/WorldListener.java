package hr.fer.zemris.optjava.GUI;

public interface WorldListener {
    void worldChanged();
}
